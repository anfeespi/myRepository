package co.edu.unbosque.model;

import java.util.ArrayList;
import java.util.Date;

/**
 * Implementacion del DAO de usuario
 * 
 * @author Andres Espitia
 * @author Diego Forero
 * @author Esteban Mejia
 * @author Camilo Uribe
 *
 */
public class UserDAOImpl implements UserDAO {
	private ArrayList<UserDTO> users;

	/**
	 * Constructor
	 */
	public UserDAOImpl() {
		super();
	}

	@Override
	public void createUser(UserDTO u) {
		users.add(u);
		// filehandler.pene
	}

	@Override
	public boolean updateUser(int index, String new_name) {
		users.get(index).setName(new_name);
		// filehandler.pene
		return true;
	}

	@Override
	public boolean updateUserLastName1(int index, String new_last_name1) {

		users.get(index).setLastname1(new_last_name1);
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUserLastName2(int index, String new_last_name2) {
		users.get(index).setLastname2(new_last_name2);
		// filehandler.pene
		return true;
	}

	@Override
	public boolean updateUserAlias(int index, String new_alias) {
		users.get(index).setAlias(new_alias);
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUserOrigin(int index, String new_origin) {
		users.get(index).setOrigin(new_origin);
		// filehandler.pene
		return false;
	}

	@Override
	public boolean updateUserResidence(int index, String new_residence) {
		users.get(index).setResidence(new_residence);
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUserContact(int index, String new_contact) {
		users.get(index).setContact(new_contact);
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUserPhotos(int index, int new_photos) {
		users.get(index).setPhotos(new_photos);
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUserLikes(int index, int new_likes) {
		users.get(index).setLikes(new_likes);
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUserMatches(int index, int new_matches) {
		users.get(index).setMatches(new_matches);
		;
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUserInterest(int index, ArrayList<String> new_interest) {
		users.get(index).setInterest(new_interest);
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUserUrlPhotos(int index, ArrayList<String> new_url_photos) {
		users.get(index).setUrl_photos(new_url_photos);
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUserOrientation(int index, String new_orientation) {
		users.get(index).setOrientation(new_orientation);
		;
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUser(int index, Date new_birth) {
		users.get(index).setBirth(new_birth);
		;
		// filehandler.pene
		return true;

	}

	@Override
	public boolean updateUser(int index, boolean new_status) {
		users.get(index).setStatus(new_status);
		// filehandler.pene
		return true;
	}

	@Override
	public boolean deleteUser(int index) {
		users.remove(index);
		// filehandler.pene
		return true;

	}

	@Override
	public ArrayList<UserDTO> showCompatibles(int index) {
		ArrayList<UserDTO> aux = new ArrayList<UserDTO>();
		String orientationaux = users.get(index).getOrientation();
		int indx = 0;
		for (int j = 0; j < OrientationDAO.orientations.size(); j++) {
			if (OrientationDAO.orientations.get(j).getOrientation().equals(orientationaux)) {
				indx = j;
				break;
			}
		}
		for (int j = 0; j < users.size(); j++) {
			String suf = "";
			if (users.get(j).isGender()) {
				suf = "H";
			} else if (!users.get(j).isGender()) {
				suf = "M";
			}

			for (int k = 0; k < OrientationDAO.orientations.get(indx).getCompatible().size(); k++) {
				if (users.get(j).getOrientation() + suf == OrientationDAO.orientations.get(indx).getCompatible()
						.get(k)) {
					aux.add(users.get(j));
				}
			}
		}

		return aux;
	}

}
