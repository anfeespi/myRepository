<html>
    <head>
        <title>Formulario Tipos</title>
    </head>
    <body style="background-color:#3FCAA2;">
        <form action="Tipos.php" method="post" >
            <table border="1" width="50%">
                <tr><td colspan="6"><b>Formulario para el Tipo de IMC</b></td></tr>
                <tr><td>Tipo</td><td><input type="Text" name="Tipo" id="Tipo" ></td></tr>
                <tr><td>IMC Menor</td><td><input type="number" name="IMC_Menor" id="IMC_Menor" ></td></tr>
                    <tr><td>IMC Mayor</td><td><input type="number" name="IMC_Mayor" id="IMC_Mayor" ></td></tr>
                  <tr><td colspan="6"><input type="submit" value="Enviar" ></td></tr>
            </table>
        </form>
    </body>
</html>