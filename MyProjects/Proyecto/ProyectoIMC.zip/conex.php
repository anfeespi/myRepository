<?php
$conex=mysqli_connect('localhost','id9610606_andresespitia','felipe102005','id9610606_proyecto_imc');
if($conex){
    //echo "¡Conexion Correcta!";
}
else{
    echo "¡Error en la Conexion!";
}

?>