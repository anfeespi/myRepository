<html>
    <head>
        <title>Formulario Musica</title>
    </head>
    <body style="background-color:#3FCAA2;">
        <form action="Music.php" method="post" >
            <table border="1" width="50%">
                <tr><td colspan="9"><b>Formulario para Musica</b></td></tr>
                <tr><td>Id_Cancion</td><td><input type="number" name="Id_Cancion" id="Cancion"></td></tr>
                <tr><td>Autor</td><td><input type="text" name="Autor" id="Autor" ></td></tr>
                <tr><td>Nombre</td><td><input type="text" name="Nombre" id="Nombre" ></td></tr>
                <tr><td>Duracion</td><td><input type="text" name="Duracion" id="Duracion" ></td></tr>
                  <tr><td colspan="9"><input type="submit" value="Enviar" ></td></tr>
            </table>
        </form>
    </body>
</html>